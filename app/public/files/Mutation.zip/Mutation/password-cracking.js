// Helper 1: query an endpoint.
async function querySite(
    siteAddress,
    queryParameter,
    query,
) {
    try {
        const target = new URL(
            siteAddress
        );

        target.searchParams.set(queryParameter, query);

        const response = await fetch(target.toString(), {
            method: "GET",
            credentials: "same-origin",
            cache: "no-store",
        });

        const data = response.status === 200
            ? await response.text()
            : null;

        return {
            status: response.status,
            data,
        };
    } catch (error) {
        return {
            status: 0,
            data: null,
            error: String(error),
        };
    }
}

// Helper 2: print the flag when the query succeeds.
function parseQueryResponse(result) {
    if (result?.status === 200 && typeof result.data === "string") {
        console.log(result.data);
        return;
    }
}