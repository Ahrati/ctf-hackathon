import math

n = ___
a = math.isqrt(n) + 1

while True:
    b2 = (a**2) - n
    b = math.isqrt(b2)
    if _________:
        ___________
        break
    a =  a + 1
    
p = a + b
q = a - b

phi_n = (p - 1) * (q - 1)

d = pow(65537, -1, phi_n)

print("\n \n")

print(phi_n)
print("\n")    
print("use this")
print(d)
print("\n")